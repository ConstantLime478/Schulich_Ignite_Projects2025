
# Session 2 Exercise 1
# Pre-made code Leaves

class Leaves:
    def __init__(self, x, y, size, color):
        self.x = x
        self.y = y
        self.size = size
        self.color = color  # Note American spelling of "colour". You can edit this to "self.colour" if you prefer Canadian style