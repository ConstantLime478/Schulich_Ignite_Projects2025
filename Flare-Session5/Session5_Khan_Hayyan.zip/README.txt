***READ ME***

In [sprite.py] I have put the file location as from "Flare-Session 4", to "assets", then to the image name. Please change the file location
to whatever is compatible to your device.

For example:   
    
    os.path.join("Flare-Session4" ,"assets", "player2.png")

THIS SHOULD BE CHANGED TO WHAT FITS YOUR DEVICE

    os.path.join("assets", "player2.png")

LIKE THIS


Thanks,
Hayyan